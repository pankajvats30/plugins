jQuery(document).ready(function(){
    
   
    jQuery('#save_setings').click(function(){
            var er=0;
            jQuery('.required').removeClass('input_error');
              jQuery('.error_label').html('');
            jQuery('#ApiFrm').find('.required').each(function(){
                
                if (jQuery(this).val()=='' ) {
                    jQuery(this).addClass('input_error');
                    jQuery(this).focus();
                    jQuery('.error_label').html('Please Fill all required fields marked in red');
                    er=1;
                }
                if (jQuery(this).val()!='' && isNaN(jQuery(this).val()) && jQuery(this).attr('id')!="api_key") {
                    jQuery(this).addClass('input_error')
                    jQuery('.error_label').html('Please enter a digits value.');
                    jQuery(this).focus();
                    er=1;
                }
                if (er==1) {
                return false;
            }else{
                return true;
            }
                
                });
            if (er==1) {
                return false;
            }else{
                return true;
            }
        
        });
    
    jQuery('#api-section').click(function(){ jQuery('#ApiFrm').slideToggle('slow')});
    jQuery('#temp-section').click(function(){ jQuery('#temp-sec').slideToggle('slow')});
    jQuery('#temp-list-section').click(function(){ jQuery('#temp-list-sec').slideToggle('slow')});
    
    /* validate add temprature */
    
      jQuery('#add_Temp').click(function(){
           
             var er=0;
            jQuery('.required').removeClass('input_error');
              jQuery('.error_label').html('');
            jQuery('#temp-sec').find('.required').each(function(){
               
                if (jQuery(this).val()=='' || isNaN(jQuery(this).val()) ) {
                    jQuery(this).addClass('input_error');
                    jQuery(this).focus();
                    jQuery('#temp_error_label').html('Please fill a valid numeric value.');
                    er=1;
                }
                if (jQuery(this).attr('id')=="temp_to" && parseFloat(jQuery('#temp_from').val())> parseFloat(jQuery('#temp_to').val())) {
                    jQuery(this).addClass('input_error');
                    jQuery(this).focus();
                    jQuery('#temp_error_label').html('"Temperature From" should be less than "Temperature To".');
                    er=1;
                }
                      
                if (er==1) {
                return false;
                }else{
                    return true;
                }
                
            });
            
            
            
            if (er==1) {
                return false;
            }else{
                return true;
            }
        
        });
    
    initialize();
    
    
}); /* end of ready function */

/* map javascript code */
var map;

    function initialize() {
        var myLatlng = new google.maps.LatLng(jQuery('#lat').val(), jQuery('#long').val());

        var myOptions = {
            zoom: 8,
            center: myLatlng,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);

        var marker = new google.maps.Marker({
            draggable: true,
            position: myLatlng,
            map: map,
            title: "Your location"
        });

        google.maps.event.addListener(marker, 'dragend', function (event) {


            document.getElementById("lat").value = event.latLng.lat();
            document.getElementById("long").value = event.latLng.lng();
        });
    }
google.maps.event.addDomListener(window, 'load', initialize);



