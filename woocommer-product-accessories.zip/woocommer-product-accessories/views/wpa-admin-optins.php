<style>
.col-left{
    width: 20%;
    font-weight: bold;
    word-wrap: break-word;
    vertical-align: top;
    
    
}
.col-right input[type="text"] {
    
    width: 270px;
}

.input_error{
    border : 1px solid #f80000 !important;
    
}
.error_label{
    
    color: #f80000;
    font-weight: bold;
}
.bhead{
    margin-right: 10px; 
}
    
</style>

<div class="wrap">
    
    <?php if(isset($msg)) :  ?><div class="updated" id="message"><p><strong>Settings updated successfully.</strong>.</p></div> <?php endif; ?>
    
    <h2>WooCommerce Accessories Tab -Settings </h2> 
    
    
    
    <form action="" method="post" id="ApiFrm"  >
    <table class="wp-list-table widefat fixed posts" style="width: 50%">
        <tr>
            <td class="col-left">Tab Title: </td>
            <td class="col-right"> <input type="text" class="required" placeholder="" name="wpa_settings[0]" value="<?php echo $wpa_settings[0]; ?>" /></td>
        </tr>
        
        <tr>
            <td></td>
            <td><input type="submit" class="button-primary" id="save_setings" value="Save Changes" /> &nbsp;&nbsp;&nbsp;<span class="error_label"></span></td>
        </tr>
        
    </table>
    <input type="hidden" name="wpa_action" value="save_settings" />
    </form>
    
</div>

