<?php /*
Plugin Name: Woocommerce Product Accessories
Description: Add Accessories product to a product .
Author:  Website Admin
*/

if ( ! defined( 'ABSPATH' ) ) { 
    exit; // Exit if accessed directly
}

define('WPA_VERSION', '1.0');
define('WPA_URL', plugin_dir_url( __FILE__ ));
define('WPA_DOCROOT',    dirname(__FILE__));


/* check for woocommerce activation */
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
    
    
    /* check for class already exists */
if ( ! class_exists( 'WC_Product_Accessories' ) ) :

Class WC_Product_Accessories  {
        
        	
        public function __construct() {
            
	   /* add admin setting page */
	   add_action('admin_menu',array(&$this,'wpa_menus'));    
	   /* add new tab next to review tab */
           add_filter( 'woocommerce_product_tabs', array(&$this,'wpa_accessories_product_tab') );
           /* add tab to admin */
	   
	   add_action( 'woocommerce_product_write_panel_tabs',  array( &$this, 'wpa_accessories_admin_tab' ) );
	   add_action( 'woocommerce_product_write_panels', array( &$this, 'wpa_accessories_product_write_panel_content' ));
	   add_action( 'woocommerce_process_product_meta', array( &$this,'wpa_product_save_tabdata') );
	   
	   //add_action( 'woocommerce_product_data_panels', array( &$this, 'wpa_accessories_admin_tab' ) );
	     /* load css to front */
        }
        
	
    
	/* add setting menu to woocommerce */
	public function wpa_menus()
	{
	    
	     add_submenu_page( 'woocommerce', 'Accessories Tab Settings', 'Accessories Tab Setting', 'manage_options', 'wpa-settings-page', array(&$this,'wpa_menu_page') );
	}
	
	/* menu page */
        
        public function wpa_menu_page()
        {
            global $wpdb;
            
           
            if(isset($_REQUEST['wpa_action']) && !empty($_REQUEST['wpa_action']))
            {
                update_option('wpa_setting',serialize($_POST['wpa_settings']));
		$msg="1";
        
            }
            
            $wpa_settings=unserialize(get_option('wpa_setting',true));
             
            include(WPA_DOCROOT.'/views/wpa-admin-optins.php');
            
            
        }
	/* Add accessories tab to product detail page in admin */
	public function wpa_accessories_admin_tab()
	{?>
	    <li class="advanced_tab advanced_options"><a href="#wpa_accessories_tabs"><?php _e( 'Accessories products', 'wpa' ); ?></a></li>
	   
	<?php    
	}
	
	/* accessories write panel tab */
	
	public function wpa_accessories_product_write_panel_content() {
		global $product,$wpdb, $thepostid, $theorder, $woocommerce,$post;
                $fwoo_url = $woocommerce->plugin_url() . 'admin/post-types/writepanels/';
		
		?>
		
		<div id="wpa_accessories_tabs" class="panel woocommerce_options_panel">

				<div class="options_group">
				<p class="form-field"><label for="accessories_products"><?php _e( 'Accessories Products', 'woocommerce' ); ?></label>
				<input type="hidden" class="wc-product-search" style="width: 50%;" id="accessories_products" name="accessories_products" data-placeholder="<?php _e( 'Search for a Accessories product&hellip;', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products" data-multiple="true" data-selected="<?php
					$product_ids = array_filter( array_map( 'absint', (array) get_post_meta( $post->ID, '_accessories_products', true ) ) );
					
					$json_ids    = array();

					foreach ( $product_ids as $product_id ) {
						$product = wc_get_product( $product_id );
						if ( is_object( $product ) ) {
							$json_ids[ $product_id ] = wp_kses_post( html_entity_decode( $product->get_formatted_name() ) );
						}
					}

					echo esc_attr( json_encode( $json_ids ) );
				?>" value="<?php echo implode( ',', array_keys( $json_ids ) ); ?>" /> <img class="help_tip" data-tip='<?php _e( 'Accessories are products which you will purchase on the base of currently viewed product.', 'woocommerce' ) ?>' src="<?php echo WC()->plugin_url(); ?>/assets/images/help.png" height="16" width="16" /></p>

				
				</div>
				<?php do_action( 'woocommerce_product_options_related' ); ?>

		</div>
      <?php
	}
	
    
	/* save accessories tab data */
	public function wpa_product_save_tabdata( $post_ID , $post ) {
	    global $post;
	   
	    if ( isset( $_POST['accessories_products'] ) ) {
	     $accessories_product_data    = isset( $_POST['accessories_products'] ) ? array_filter( array_map( 'intval', explode( ',', $_POST['accessories_products'] ) ) ) : array();
	     update_post_meta( $post_ID, '_accessories_products', $accessories_product_data );
	    } else {
	    delete_post_meta( $post_ID, '_accessories_products' );
	    }
	}
	
	/* front product detail accosserious tab */
	public function wpa_accessories_product_tab( $tabs ) {
	    // Adds the new tab
	    global $wpdb;
	    $wpa_settings=unserialize(get_option('wpa_setting',true));
	    
	    $tabs['wpa_access_tab'] = array(
	    'title' => __($wpa_settings[0], 'woocommerce' ),
	    'priority' => 50,
	    'callback' => array(&$this,'wpa_access_product_tab_content')
	    );
	    return $tabs;
	}
	
	/* front product detail accosserious tab content */
	public function wpa_access_product_tab_content() {
	     global $post, $product, $woocommerce;
	    
	// The new tab content
		
	$associative_ids = get_post_meta($product->id, '_accessories_products', true);
        $main_product_id = $product->id;
        $main_product_type = $product->product_type;
        if (!empty($associative_ids)):
            ?>
            <?php //$associative_ids = array_reverse($associative_ids); print_r($associative_ids);?>
            <?php foreach ($associative_ids as $pid): ?>
                <?php if (get_the_title($pid)): ?>
                    <div class="order clearfix">
                        <?php
                        $product = get_product($pid);
			
			$cart_btn='woocommerce_' . $product->product_type . '_add_to_cart';
                        $_product_new = &new WC_Product($pid);
                        ?>
                        <?php
			
                        $product->id = $pid;
                        $product->product_type = $_product_new->product_type
                        ?>
                        <figure>			
                            <?php
                            if (has_post_thumbnail($pid))
                                echo get_the_post_thumbnail($pid, array(67, 67));
                            else
			    echo apply_filters( 'woocommerce_single_product_image_html', sprintf( '<img src="%s" height="67" width="67" alt="Placeholder" />', woocommerce_placeholder_img_src() ), $pid );
			    ?>
                            <?php do_action('woocommerce_single_product_associated_single_sharing'); ?>
                        </figure>
                        <div class="order_right">
                            <h5><?php echo get_the_title($pid);  ?></h5>
                            <p><?php do_action('woocommerce_single_product_associated_price'); ?>
			    
                                <?php echo get_woocommerce_currency_symbol() . $_product_new->price; ?> </p>

                            <div class="order_right_01">

                                <ul>
                                    <li><?php do_action($cart_btn); ?></li>

                                </ul>
                            </div>

                        </div>					
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>  
        <?php endif;
	
	
	} 
	
     
        
  
    } /* end of class */


endif; /* end of class duplicate check */

$pbwObj=new WC_Product_Accessories();


register_activation_hook(__FILE__, array(&$pbwObj,'pbw_Installer') );

} /* end of woocommerce activation check */



/* uninstall plugin */

register_uninstall_hook(__FILE__, 'pbw_Unistaller');
function pbw_Unistaller()
{
  global $wpdb;
  delete_option('pbw_api_settings');
  $wpdb->query('DROP TABLE IF EXISTS `'.$wpdb->prefix.'pbw_tempratures`');
}




?>