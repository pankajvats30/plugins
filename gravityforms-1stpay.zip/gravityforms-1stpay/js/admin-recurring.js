/*!
WordPress plugin gravityforms-proc
copyright (c) 2012-2014 WebAware Pty Ltd, released under LGPL v2.1
form editor for Recurring Payments field
*/

// create namespace to avoid collisions
var GFProcRecurring = (function($) {

	return {
		/**
		* set the label on a subfield in the recurring field
		* @param {HTMLElement} field
		* @param {String} defaultValue
		*/
		SetFieldLabel : function(field, defaultValue) {
			var newLabel = field.value;

			// if new label value is empty, pick up the default value instead
			if (!(/\S/.test(newLabel)))
				newLabel = defaultValue;

			// set the new label, and record for the field
			$("." + field.id).text(newLabel);
			SetFieldProperty(field.id, newLabel);
		},

		/**
		* toggle whether to show the Initial Amount and Initial Date fields
		* @param {HTMLElement} field
		*/
		ToggleInitialSetting : function(field) {
			SetFieldProperty(field.id, field.checked);
			if (field.checked) {
				$("#gfproc_initial_fields").slideDown();
			}
			else {
				$("#gfproc_initial_fields").slideUp();
			}
		},

		/**
		* toggle whether to show the Start Date and End Date fields
		* @param {HTMLElement} field
		*/
		ToggleRecurringDateSetting : function(field) {
			SetFieldProperty(field.id, field.checked);
			if (field.checked) {
				$("#gfproc_recurring_date_fields").slideDown();
			}
			else {
				$("#gfproc_recurring_date_fields").slideUp();
			}
		}
	};

})(jQuery);

// initialise form on page load
jQuery(function($) {

	// add required classes to the field on the admin form
	fieldSettings.gfprocrecurring = ".conditional_logic_field_setting, .error_message_setting, .label_setting, .admin_label_setting, .rules_setting, .description_setting, .css_class_setting, .gfprocrecurring_setting";

	// binding to the load field settings event to initialize custom inputs
	$(document).bind("gform_load_field_settings", function(event, field, form) {

		$("#gfproc_initial_setting").prop("checked", !!field.gfproc_initial_setting);
		if (!field.gfproc_initial_setting) {
			$("#gfproc_initial_fields").hide();
		}

		$("#gfproc_recurring_date_setting").prop("checked", !!field.gfproc_recurring_date_setting);
		if (!field.gfproc_recurring_date_setting) {
			$("#gfproc_recurring_date_fields").hide();
		}

		$("#gfproc_initial_amount_label").val(field.gfproc_initial_amount_label);
		$("#gfproc_recurring_amount_label").val(field.gfproc_recurring_amount_label);
		$("#gfproc_initial_date_label").val(field.gfproc_initial_date_label);
		$("#gfproc_start_date_label").val(field.gfproc_start_date_label);
		$("#gfproc_end_date_label").val(field.gfproc_end_date_label);
		$("#gfproc_interval_type_label").val(field.gfproc_interval_type_label);

	});

});
