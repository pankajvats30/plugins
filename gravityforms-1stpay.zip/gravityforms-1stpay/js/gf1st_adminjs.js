
GF1PAY = jQuery.noConflict();

GF1PAY( document ).ready(function( $ ) {
    
   
   GF1PAY('#add_tran_id').on('click',function(){
       var error=0;
        GF1PAY('#error_msg').html('');
        GF1PAY('#suc_msg').html('');
      if(!GF1PAY.trim(GF1PAY('input[name="GF1st_tranCenter_id"]').val()))
      {
          
         
         GF1PAY('#error_msg').html('Error: Transaction Center Id is blank.');
          GF1PAY('input[name="GF1st_tranCenter_id"]').focus(); return false;
          error=1;
      }
      if(!GF1PAY.trim(GF1PAY('input[name="GF1st_username"]').val()))
      {

          GF1PAY('#error_msg').html('Error: Username is Blank.');
          GF1PAY('input[name="GF1st_username"]').focus();return false;
          error=1;
      } 
       if(!GF1PAY.trim(GF1PAY('input[name="GF1st_password"]').val()))
       {
          GF1PAY('#error_msg').html('Error: Password is Blank.');
          GF1PAY('input[name="GF1st_password"]').focus(); return false;
          error=1;
      } 
       var data = { action:'add_tids',
                    tran_id: GF1PAY.trim(GF1PAY('input[name="GF1st_tranCenter_id"]').val()),
                    user_name :  GF1PAY.trim(GF1PAY('input[name="GF1st_username"]').val()),
                    password:  GF1PAY.trim(GF1PAY('input[name="GF1st_password"]').val()),
                
               }
         GF1PAY.ajax({
                url: ajax_object.ajax_url,
                type:'post',
                data: data,
                dataType:'json',
                success:function (res)
                {
                       
                    if(res.res=='success')
                    {
                        GF1PAY('input[name="GF1st_tranCenter_id"]').val('');
                        GF1PAY('input[name="GF1st_username"]').val('');
                        GF1PAY('input[name="GF1st_password"]').val('');
                        GF1PAY('#suc_msg').html('Transaction Center Id Added Successfully');
                        getGF1stpay_tids();
                        setTimeout(function(){GF1PAY('#suc_msg').html('');GF1PAY('#error_msg').html('');},4000);
                    
                    }

                }
        
        });
      
       
       
   });
   
   GF1PAY('#add_GF1stpay_centers').on('click',function(){
       var error=0;
        GF1PAY('#error_msg').html('');
        GF1PAY('#suc_msg').html('');
      if(!GF1PAY.trim(GF1PAY('input[name="GF1st_tranCenter_name"]').val()))
      {
          
         
         GF1PAY('#error_msg').html('Error: Transaction Center Name is blank.');
          GF1PAY('input[name="GF1st_tranCenter_name"]').focus(); return false;
          
      }
      if(!GF1PAY.trim(GF1PAY('#GF1st_tranCenter_ids').val()))
      {

          GF1PAY('#error_msg').html('Error: Transaction Center Id is blank');
          GF1PAY('input[name="GF1st_tranCenter_ids"]').focus();return false;
          
      } 
      
       var data = { action:'add_centers',
                    center_name: GF1PAY.trim(GF1PAY('input[name="GF1st_tranCenter_name"]').val()),
                    center_tid :  GF1PAY.trim(GF1PAY('#GF1st_tranCenter_ids').val()),
                  
                
               }
         GF1PAY.ajax({
                url: ajax_object.ajax_url,
                type:'post',
                data: data,
                dataType:'json',
                success:function (res)
                {
                       
                    if(res.res=='success')
                    {
                        GF1PAY('input[name="GF1st_tranCenter_name"]').val('');
                        GF1PAY('#GF1st_tranCenter_ids').val('');
                       
                        GF1PAY('#suc_msg').html('Center Added Successfully');
                        getGF1stpay_centers()
                       
                    
                    }

                }
        
        });
      
       
       
   });
   
   /* delete centers */
    GF1PAY('#GF1stpay_delCenters').on('click',function(){
        getGF1stpay_deleteCenters();
    });
   
    getGF1stpay_tids(); /* fetch the tids list */
    getGF1stpay_centers(); /* fetch the center ids  */
    
    
}); /* end of readu function */
    

function getGF1stpay_tids()
{
    
    var data = { action:'get_tids'

               }
         GF1PAY.ajax({
                url: ajax_object.ajax_url,
                type:'post',
                data: data,
                dataType:'json',
                success:function (res)
                {
                       
                    if(res.res=='success')
                    {   GF1PAY('#GF1st_tranCenter_ids').html('');
                        GF1PAY('#GF1st_tranCenter_ids').append('<option value="">Select Center Id</option>');
                        GF1PAY.each(res.data,function(id,data){
                        GF1PAY('#GF1st_tranCenter_ids').append('<option value="'+data.tid+'">'+data.transaction_id+'-'+data.username+'</option>');
								
							});		
                    
                    }

                }
        
        });
    
}
function getGF1stpay_centers()
{
    
    var data = { action:'get_centers'

               }
         GF1PAY.ajax({
                url: ajax_object.ajax_url,
                type:'post',
                data: data,
                dataType:'json',
                success:function (res)
                {
                       
                    if(res.res=='success')
                    {   GF1PAY('#GF1stpay_SavedCenters').html('');
                        
                        GF1PAY.each(res.data,function(id,data){
                        GF1PAY('#GF1stpay_SavedCenters').append('<option value="'+data.cid+'">'+data.center_name+' - '+data.transaction_id+'</option>');
								
							});		
                    
                    }

                }
        
        });
    
}
function getGF1stpay_deleteCenters()
{
    GF1PAY('#del_error_msg').html('');
        GF1PAY('#del_suc_msg').html('');
       if(!GF1PAY('#GF1stpay_SavedCenters').val())
       {
            GF1PAY('#del_error_msg').html('Error: Please select an center before delete '); return false; 
       }
   if(confirm('Are you sure want to delete ?'))
   {
           
        var data = { action:'del_centers',
                 cids: GF1PAY('#GF1stpay_SavedCenters').val()  
               }
         GF1PAY.ajax({
                url: ajax_object.ajax_url,
                type:'post',
                data: data,
                dataType:'json',
                success:function (res)
                {
                       
                    if(res.res=='success')
                    {   
                        GF1PAY('#del_suc_msg').html('Center(s) Deleted Successfully');
                        getGF1stpay_centers()
                    
                    }

                }
        
        });
    }
    else
    {
        return false;
    }    
}