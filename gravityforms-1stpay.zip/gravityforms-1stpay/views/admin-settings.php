<div class='wrap'>
<h3>Gravity Forms 1stPay Payments Options</h3>
<div class="gfset-left" >
	<h4 id="error_msg">&nbsp;</h4>
	<h4  id="suc_msg">&nbsp;</h4>
	<table class="form-table">
	
		
		<tr>
			
			<th>Transaction Center Id</th>
			<td>
				<input type='text' class="regular-text" name='GF1st_tranCenter_id' value="<?php echo esc_attr($this->frm->GF1st_tranCenter_id); ?>" />
			</td>
		</tr>
		<tr>
			
			<th>User Name</th>
			<td>
				<input type='text' class="regular-text" name='GF1st_username' value="<?php echo esc_attr($this->frm->GF1st_username); ?>" />
			</td>
		</tr>
		<tr>
			
			<th>Password</th>
			<td>
				<input type='password' class="regular-text" name='GF1st_password' value="<?php echo esc_attr($this->frm->GF1st_password); ?>" />
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><p class="gf-btnArea">
					<input type="button" name="Submit" id="add_tran_id" class="button-primary" value="Add Center ID" />
	<input type="hidden" name="action" value="save" />
	<?php wp_nonce_field('save', $this->menuPage . '_wpnonce', false); ?>
	</p></td>
			
		</tr>

	</table>
	
<form action="<?php echo $this->scriptURL; ?>" method="post" id="proc-settings-form">	
	<table class="form-table">
	
		<tr>
			
			<th>Center Name :</th>
			<td>
				<input type='text' class="regular-text" name='GF1st_tranCenter_name' value="<?php echo esc_attr($this->frm->GF1st_tranCenter_id); ?>" />
			</td>
		</tr>
		<tr>
			
			<th>Select Center Id :</th>
			<td>
				<select name="GF1st_tranCenter_ids" id="GF1st_tranCenter_ids" style="width:100%;">
					<option>Select Center Id</option>
					
				</select>
			</td>
		</tr>
		
		<tr>
			<td>&nbsp;</td>
			<td><p class="gf-btnArea">
					<input type="button" name="add_GF1stpay_centers" id="add_GF1stpay_centers" class="button-primary" value="Add Center" />
	<input type="hidden" name="action" value="save" />
	<?php wp_nonce_field('save', $this->menuPage . '_wpnonce', false); ?>
	</p></td>
			
		</tr>

	</table>
	
	
</form>
</div>

<div class="gfset-right" style="float: left">
	<h3>Active TIDs</h3>
	<select multiple="multiple" name="GF1stpay_SavedCenters" id="GF1stpay_SavedCenters" size="25" style="width: 100%" >
		
		
		
	</select>
	<span>Please Press CTRL to select multuple TIDs</span>
	<p class="gf-btnArea">
		<input type="button" name="GF1stpay_delCenters" id="GF1stpay_delCenters" class="button-primary" value="Delete" />
		<h4 id="del_error_msg">&nbsp;</h4>
	<h4  id="del_suc_msg">&nbsp;</h4>
	</p>
	
	
</div>



</div> <!-- end of warp div -->

<script>
(function($) {

	/**
	* check whether both the sandbox (test) mode and Stored Payments are selected,
	* show warning message if they are
	*/
	function setVisibility() {
		var	useTest = ($("input[name='useTest']:checked").val() == "Y"),
			useBeagle = ($("input[name='useBeagle']:checked").val() == "Y"),
			useStored = ($("input[name='useStored']:checked").val() == "Y");

		function display(element, visible) {
			if (visible)
				element.css({display: "none"}).show(750);
			else
				element.hide();
		}

		display($("#gfproc-opt-admin-stored-test"), (useTest && useStored));
		display($("#gfproc-opt-admin-stored-beagle"), (useBeagle && useStored));
		display($("#gfproc-opt-admin-beagle-address"), useBeagle);
	}

	$("#proc-settings-form").on("change", "input[name='useTest'],input[name='useBeagle'],input[name='useStored']", setVisibility);

	setVisibility();

})(jQuery);
</script>
