<?php


class GF1stpayInstaller {
	
	public function __construct() {
		global $wpdb;
		register_activation_hook(__FILE__, array($this,'GF1stpay_installDb') );
		register_uninstall_hook(__FILE__, array($this,'GF1stpay_uninstallDb'));
	}
	
	public function  GF1stpay_installDb()
	{
		global $wpdb,$wp;
		
		 $sql='
        CREATE TABLE IF NOT EXISTS `' . GF1STPAY_TID_TABLE . '` (
          `tid` bigint unsigned NOT NULL AUTO_INCREMENT,
          `transaction_id` varchar(500)  NOT NULL,
          `username` varchar(500)  NOT NULL,
          `password` varchar(500) NOT NULL,
          PRIMARY KEY (`tid`),
          UNIQUE KEY `id` (`tid`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
    ';
	$wpdb->query($sql);	 
	 $sql2='
        CREATE TABLE IF NOT EXISTS `' . GF1STPAY_CENTERS_TABLE . '` (
          `cid` bigint unsigned NOT NULL AUTO_INCREMENT,
          `center_name` varchar(500)  NOT NULL,
          `center_tid` varchar(500)  NOT NULL,
          PRIMARY KEY (`cid`),
          UNIQUE KEY `id` (`cid`)
        ) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
    ';
	 $wpdb->query($sql2);	
	}

	public function  GF1stpay_uninstallDb()
	{
		 dbDelta('
       DROP TABLE IF EXISTS `'.GF1STPAY_TID_TABLE.'`;
	   DROP TABLE IF EXISTS `'.GF1STPAY_CENTERS_TABLE.'`;	   
    ');
	}	
	
}// end of class

?>