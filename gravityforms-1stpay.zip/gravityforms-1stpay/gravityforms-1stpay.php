<?php
/*
Plugin Name: Gravity Forms Donation With 1stPay
Plugin URI: http://nethues.com
Description: Integrates Gravity Forms with 1stpay payment gateway for donations with multiple center ids .
Version: 1.0.0
Author: Nethues
Author URI: http://nethues.com
*/

global $wpdb;

if (!defined('GF1STPAY_PLUGIN_ROOT')) {
	define('GF1STPAY_PLUGIN_ROOT', dirname(__FILE__) . '/');
	define('GF1STPAY_PLUGIN_NAME', basename(dirname(__FILE__)) . '/' . basename(__FILE__));
	define('GF1STPAY_PLUGIN_FILE', __FILE__);
	define('GF1STPAY_PLUGIN_OPTIONS', 'gf1stpay_plugin');
	define('GF1STPAY_PLUGIN_VERSION', '1.6.1');

	// error message names
	define('GF1STPAY_ERROR_ALREADY_SUBMITTED', 'gf1stpay_err_already');
	define('GF1STPAY_ERROR_NO_AMOUNT', 'gf1stpay_err_no_amount');
	define('GF1STPAY_ERROR_REQ_CARD_HOLDER', 'gf1stpay_err_req_card_holder');
	define('GF1STPAY_ERROR_REQ_CARD_NAME', 'gf1stpay_err_req_card_name');
	define('GF1STPAY_ERROR_PROC_FAIL', 'gf1stpay_err_proc_fail');
	define('GF1STPAY_TID_TABLE',$wpdb->prefix."gf1stpay_tids");
	define('GF1STPAY_CENTERS_TABLE',$wpdb->prefix."gf1stpay_centers");
	// custom fields
	define('GF1STPAY_FIELD_RECURRING', 'gf1stpayrecurring');
}

/**
* autoload classes as/when needed
*
* @param string $class_name name of class to attempt to load
*/
function gf1stpay_autoload($class_name) {
	static $classMap = array (
		'GF1stpayInstaller'						=> 'libs/class.GF1stpayInstaller.php',
		'GF1stpayAdmin'						=> 'libs/class.GF1stpayAdmin.php',
		'GF1stpayFormData'					=> 'libs/class.GF1stpayFormData.php',
		'GF1stpayOptionsAdmin'				=> 'libs/class.GF1stpayOptionsAdmin.php',
		'GF1stpayPayment'						=> 'libs/class.GF1stpayPayment.php',
		'GF1stpayPlugin'						=> 'libs/class.GF1stpayPlugin.php',
		'GF1stpayRecurringField'				=> 'libs/class.GF1stpayRecurringField.php',
		'GF1stpayRecurringPayment'			=> 'libs/class.GF1stpayRecurringPayment.php',
		'GF1stpayStoredPayment'				=> 'libs/class.GF1stpayStoredPayment.php',
	);

	if (isset($classMap[$class_name])) {
		require GF1STPAY_PLUGIN_ROOT . $classMap[$class_name];
	}
}
spl_autoload_register('gf1stpay_autoload');

// instantiate the plug-in
GF1stpayPlugin::getInstance();
