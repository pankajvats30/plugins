<?php
/* all redirect and admin opiton class */
class rsmBasicActions
{
    public $rsm_server_url="";
    public static function RSMgetInstance() {
		static $instance = NULL;
    
		if (is_null($instance)) {
			$instance = new self();
		}
    
		return $instance;
	}
   public  function __construct()
    {
	/* load javascript and css */
       add_action('admin_init',array(&$this,'rsmAddJqueryAndCss'));
       /* add admin menu */
       add_action('admin_menu',array(&$this,'rsmAdminMenus'));
    }
   
    /* create plugin menu in admin */
    public function rsmAdminMenus()
    {
        global $wpdb; 
        add_menu_page('Budget Calculator', 'Budget Calculator', 'administrator','rsm-options-page');
        add_submenu_page('rsm-options-page', 'Budget Calculator', 'Budget Calculator','administrator', 'rsm-options-page', array(&$this,'rsmAdminView'));   
        
    }
    
    /* load the admin section view */
    public function rsmAdminView()
    {
         if(isset($_POST) && isset($_POST['rsmSubBtn']))
	 {
	    /* update values to option table */
	    $rsm_y1=($_POST['rsm_y1'])? trim($_POST['rsm_y1']) : '';
	    $rsm_y2=($_POST['rsm_y2'])? trim($_POST['rsm_y2']) : '';
	    $rsm_max_allowable_pension_threshold_y1=($_POST['rsm_max_allowable_pension_threshold_y1'])? trim($_POST['rsm_max_allowable_pension_threshold_y1']) : '';
	    $rsm_max_allowable_pension_threshold_y2=($_POST['rsm_max_allowable_pension_threshold_y2'])? trim($_POST['rsm_max_allowable_pension_threshold_y2']) : '';
	    
	    $rsm_max_allowable_pension_threshold_M2_y1=($_POST['rsm_max_allowable_pension_threshold_M2_y1'])? trim($_POST['rsm_max_allowable_pension_threshold_M2_y1']) : '';
	    $rsm_max_allowable_pension_threshold_M2_y2=($_POST['rsm_max_allowable_pension_threshold_M2_y2'])? trim($_POST['rsm_max_allowable_pension_threshold_M2_y2']) : '';
	    
	    /* age option */
	    $rsm_max_pension_age_y1=($_POST['rsm_max_pension_age_y1'])? $_POST['rsm_max_pension_age_y1'] : '';
	    $rsm_max_pension_age_y2=($_POST['rsm_max_pension_age_y2'])? $_POST['rsm_max_pension_age_y2'] : '';
	    
	    /* Tax payable */
	    $rsm_payable_y1=($_POST['rsm_payable_y1'])? $_POST['rsm_payable_y1'] : '';
	    $rsm_payable_y2=($_POST['rsm_payable_y2'])? $_POST['rsm_payable_y2'] : '';
	    
	     /* Tax Cutoff Figure */
	    $rsm_tax_cutoff_fig_y1=($_POST['rsm_tax_cutoff_fig_y1'])? $_POST['rsm_tax_cutoff_fig_y1'] : '';
	    $rsm_tax_cutoff_fig_y2=($_POST['rsm_tax_cutoff_fig_y2'])? $_POST['rsm_tax_cutoff_fig_y2'] : '';
	    
	    /* Income Exempt  */
	    $rsm_inc_exemp_y1=($_POST['rsm_inc_exemp_y1'])? $_POST['rsm_inc_exemp_y1'] : '';
	    $rsm_inc_exemp_y2=($_POST['rsm_inc_exemp_y2'])? $_POST['rsm_inc_exemp_y2'] : '';
	     
	    /* PRSI   */
	    $rsm_prsi_opt_y1=($_POST['rsm_prsi_opt_y1'])? $_POST['rsm_prsi_opt_y1'] : '';
	    $rsm_prsi_opt_y2=($_POST['rsm_prsi_opt_y2'])? $_POST['rsm_prsi_opt_y2'] : '';
	    
	     /* Income exempt from USC  */
	    $rsm_inc_expUSC_y1=($_POST['rsm_inc_expUSC_y1'])? $_POST['rsm_inc_expUSC_y1'] : '';
	    $rsm_inc_expUSC_y2=($_POST['rsm_inc_expUSC_y2'])? $_POST['rsm_inc_expUSC_y2'] : '';
	    
	    /* USC Threshold  */
	    $rsm_usc_thres_y1=($_POST['rsm_usc_thres_y1'])? $_POST['rsm_usc_thres_y1'] : '';
	    $rsm_usc_thres_y2=($_POST['rsm_usc_thres_y2'])? $_POST['rsm_usc_thres_y2'] : '';
	    
	     /* USC Percentage  */
	    $rsm_usc_percent_y1=($_POST['rsm_usc_percent_y1'])? $_POST['rsm_usc_percent_y1'] : '';
	    $rsm_usc_percent_y2=($_POST['rsm_usc_percent_y2'])? $_POST['rsm_usc_percent_y2'] : '';
	    
	     /* Tax credits  */
	    $rsm_tex_credits_y1=($_POST['rsm_tex_credits_y1'])? $_POST['rsm_tex_credits_y1'] : '';
	    $rsm_tex_credits_y2=($_POST['rsm_tex_credits_y2'])? $_POST['rsm_tex_credits_y2'] : '';
	    
	    /* validate the all fields*/
	    if(empty($rsm_y1) || empty($rsm_y2) || $rsm_max_allowable_pension_threshold_y1=='' ||  $rsm_max_allowable_pension_threshold_y2=='')
	    {
		echo '<div class="error"><p><storng> Error: Please fill the all required fields marked with <span class="rsm_req">*</span></storng></p></div>'; 
	    }else{
		/* update the values to the database */
		update_option('rsm_y1',$rsm_y1);
		update_option('rsm_y2',$rsm_y2);
		
		update_option('rsm_max_allowable_pension_threshold_y1',$rsm_max_allowable_pension_threshold_y1);
		update_option('rsm_max_allowable_pension_threshold_y2',$rsm_max_allowable_pension_threshold_y2);
		
		update_option('rsm_max_allowable_pension_threshold_M2_y1',$rsm_max_allowable_pension_threshold_M2_y1);
		update_option('rsm_max_allowable_pension_threshold_M2_y2',$rsm_max_allowable_pension_threshold_M2_y2);
		
		/* age options */
		update_option('rsm_max_pension_age_y1',serialize($rsm_max_pension_age_y1));
		update_option('rsm_max_pension_age_y2',serialize($rsm_max_pension_age_y2));
		
		/* Tax payable */
		update_option('rsm_payable_y1',serialize($rsm_payable_y1));
		update_option('rsm_payable_y2',serialize($rsm_payable_y2));
		
		/* Tax Cutoff Figure */
		update_option('rsm_tax_cutoff_fig_y1',serialize($rsm_tax_cutoff_fig_y1));
		update_option('rsm_tax_cutoff_fig_y2',serialize($rsm_tax_cutoff_fig_y2));
		
		/* Income Exempt  */
		update_option('rsm_inc_exemp_y1',serialize($rsm_inc_exemp_y1));
		update_option('rsm_inc_exemp_y2',serialize($rsm_inc_exemp_y2));
		
		/* PRSI   */
		update_option('rsm_prsi_opt_y1',serialize($rsm_prsi_opt_y1));
		update_option('rsm_prsi_opt_y2',serialize($rsm_prsi_opt_y2));  
		
		/* Income exempt from USC  */
		update_option('rsm_inc_expUSC_y1',serialize($rsm_inc_expUSC_y1));
		update_option('rsm_inc_expUSC_y2',serialize($rsm_inc_expUSC_y2));
		
		 /* USC Threshold  */
		update_option('rsm_usc_thres_y1',serialize($rsm_usc_thres_y1));
		update_option('rsm_usc_thres_y2',serialize($rsm_usc_thres_y2));
		
		/* USC Percentage  */
		update_option('rsm_usc_percent_y1',serialize($rsm_usc_percent_y1));
		update_option('rsm_usc_percent_y2',serialize($rsm_usc_percent_y2));
		
		 /* Tax credits  */
		 update_option('rsm_tex_credits_y1',serialize($rsm_tex_credits_y1));
		 update_option('rsm_tex_credits_y2',serialize($rsm_tex_credits_y2));
		 
		echo '<div class="updated"><p><storng> Information Updated Successfully </storng></p></div>';    
	    }
	 
	 }
	 
	 /* age options */
	 $saved_rsm_max_pension_age_y1=(unserialize(get_option('rsm_max_pension_age_y1',false)))? unserialize(get_option('rsm_max_pension_age_y1',false)) : array() ;
	 $saved_rsm_max_pension_age_y2=(unserialize(get_option('rsm_max_pension_age_y2',false)))? unserialize(get_option('rsm_max_pension_age_y2',false)) : array() ;
	
	 /* Tax payable */
	 $saved_rsm_payable_y1=(unserialize(get_option('rsm_payable_y1',false)))? unserialize(get_option('rsm_payable_y1',false)) : array() ;
	 $saved_rsm_payable_y2=(unserialize(get_option('rsm_payable_y2',false)))? unserialize(get_option('rsm_payable_y2',false)) : array() ;
	
	 /* Tax Cutoff Figure */
	 $saved_rsm_tax_cutoff_fig_y1=(unserialize(get_option('rsm_tax_cutoff_fig_y1',false)))? unserialize(get_option('rsm_tax_cutoff_fig_y1',false)) : array() ;
	 $saved_rsm_tax_cutoff_fig_y2=(unserialize(get_option('rsm_tax_cutoff_fig_y2',false)))? unserialize(get_option('rsm_tax_cutoff_fig_y2',false)) : array() ;
	
	 /* Income Exempt  */
	 $saved_rsm_inc_exemp_y1=(unserialize(get_option('rsm_inc_exemp_y1',false)))? unserialize(get_option('rsm_inc_exemp_y1',false)) : array() ;
	 $saved_rsm_inc_exemp_y2=(unserialize(get_option('rsm_inc_exemp_y2',false)))? unserialize(get_option('rsm_inc_exemp_y2',false)) : array() ;
	 
	 /* PRSI  */
	 $saved_rsm_prsi_opt_y1=(unserialize(get_option('rsm_prsi_opt_y1',false)))? unserialize(get_option('rsm_prsi_opt_y1',false)) : array() ;
	 $saved_rsm_prsi_opt_y2=(unserialize(get_option('rsm_prsi_opt_y2',false)))? unserialize(get_option('rsm_prsi_opt_y2',false)) : array() ;
	
	 /* Income exempt from USC  */
	 $saved_rsm_inc_expUSC_y1=(unserialize(get_option('rsm_inc_expUSC_y1',false)))? unserialize(get_option('rsm_inc_expUSC_y1',false)) : array() ;
	 $saved_rsm_inc_expUSC_y2=(unserialize(get_option('rsm_inc_expUSC_y2',false)))? unserialize(get_option('rsm_inc_expUSC_y2',false)) : array() ;
	 
	  /* USC Threshold  */
	 $saved_rsm_usc_thres_y1=(unserialize(get_option('rsm_usc_thres_y1',false)))? unserialize(get_option('rsm_usc_thres_y1',false)) : array() ;
	 $saved_rsm_usc_thres_y2=(unserialize(get_option('rsm_usc_thres_y2',false)))? unserialize(get_option('rsm_usc_thres_y2',false)) : array() ;
	 
	 /* USC Percentage  */
	 $saved_rsm_usc_percent_y1=(unserialize(get_option('rsm_usc_percent_y1',false)))? unserialize(get_option('rsm_usc_percent_y1',false)) : array() ;
	 $saved_rsm_usc_percent_y2=(unserialize(get_option('rsm_usc_percent_y2',false)))? unserialize(get_option('rsm_usc_percent_y2',false)) : array() ;
	 
	 /* Tax credits  */
	 $saved_rsm_tex_credits_y1=(unserialize(get_option('rsm_tex_credits_y1',false)))? unserialize(get_option('rsm_tex_credits_y1',false)) : array() ;
	 $saved_rsm_tex_credits_y2=(unserialize(get_option('rsm_tex_credits_y2',false)))? unserialize(get_option('rsm_tex_credits_y2',false)) : array() ;
	 
	 include RSM_DOCROOT . '/views/rsm_admin_view.php';
    }
    
    /* load admin javascript and CSS */
    public function rsmAddJqueryAndCss()
    {
          /* load javascript and css only to plugni page */
          $path=pathinfo($_SERVER['REQUEST_URI']);
          
          if(is_admin() && $path['basename']=="admin.php?page=rsm-options-page"){
               
               wp_register_script('RSM_JqueryValidate', 'http://ajax.aspnetcdn.com/ajax/jquery.validate/1.13.0/jquery.validate.min.js', array('jquery'));
               wp_enqueue_script("RSM_JqueryValidate");
               wp_register_script('RSM_custom', RSM_PLUGURL . 'js/rsm-custom.js', array('jquery'));
               wp_enqueue_script("RSM_custom");
              
                /* include css */
                wp_enqueue_style("RSMCss", RSM_PLUGURL . 'css/rsm_style.css' );
              
          }
         
    }
   
    
}/* end of class */


?>