<?php
/* widget shortcode class */

class rsmInstaller {
  
  public static function RSMgetInstance() {
		static $instance = NULL;

		if (is_null($instance)) {
			$instance = new self();
		}

		return $instance;
	}
  
   /* call the installation hook */
    public function rsmInstaller()
    {
        global $wpdb;
        /* add the values to the database */
		add_option('rsm_y1');
		add_option('rsm_y2');
		
		add_option('rsm_max_allowable_pension_threshold_y1');
		add_option('rsm_max_allowable_pension_threshold_y2');
		
		add_option('rsm_max_allowable_pension_threshold_M2_y1');
		add_option('rsm_max_allowable_pension_threshold_M2_y2');
		
		/* age options */
		add_option('rsm_max_pension_age_y1');
		add_option('rsm_max_pension_age_y2');
		
		/* Tax payable */
		add_option('rsm_payable_y1');
		add_option('rsm_payable_y2');
		
		/* Tax Cutoff Figure */
		add_option('rsm_tax_cutoff_fig_y1');
		add_option('rsm_tax_cutoff_fig_y2');
		
		/* Income Exempt  */
		add_option('rsm_inc_exemp_y1');
		add_option('rsm_inc_exemp_y2');
		
		/* PRSI   */
		add_option('rsm_prsi_opt_y1');
		add_option('rsm_prsi_opt_y2');  
		
		/* Income exempt from USC  */
		add_option('rsm_inc_expUSC_y1');
		add_option('rsm_inc_expUSC_y2');
		
		 /* USC Threshold  */
		add_option('rsm_usc_thres_y1');
		add_option('rsm_usc_thres_y2');
		
		/* USC Percentage  */
		add_option('rsm_usc_percent_y1');
		add_option('rsm_usc_percent_y2');
		
		 /* Tax credits  */
		 add_option('rsm_tex_credits_y1');
		 add_option('rsm_tex_credits_y2');
    }
       
  
}/* end of class */





?>