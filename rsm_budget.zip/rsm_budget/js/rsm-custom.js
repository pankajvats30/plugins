jQuery( document ).ready(function( $ ) {
    
          jQuery('#rsmSubBtn').click(function(){
         er=0;
          var yr = /^[0-9]+$/;
         jQuery('#rsm_calFrm').find('input[type="text"]').each(function( index ) {
             jQuery(this).removeClass('rsm_input_error');
              jQuery(this).parent().find('span.rsm_error').remove();
             if(!jQuery.isNumeric(jQuery(this).val()) || !jQuery(this).val())
             {
               jQuery(this).addClass('rsm_input_error');
               jQuery('<span class="rsm_error"><br/>Please enter a  valid numeric value.</span>').insertAfter(jQuery(this));
              er=1;
             }

            if ((jQuery(this).attr('name')=='rsm_y1'  || jQuery(this).attr('name')=='rsm_y2') && (isNaN(jQuery(this).val()) || jQuery(this).val().length!=4)) {
                 jQuery(this).addClass('rsm_input_error');
                jQuery('<span class="rsm_error"><br/>Please enter a valid Year eg. 2014</span>').insertAfter(jQuery(this));
              er=1;
             }
           
             });
         
         
         if (er) {
            return false;
         }
         
       
            });
    
}); /* end of ready function */

