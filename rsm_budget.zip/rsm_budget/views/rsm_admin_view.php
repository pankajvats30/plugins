<div class="wrap">
  <h2>Budget Calculator Options</h2>
  <br/>
  
  <form action="admin.php?page=rsm-options-page" method="post" id="rsm_calFrm">
    <table width="100%" class="wp-list-table widefat fixed pages" cellspacing="0" cellpadding="0">
      <thead>
      <tr class="rsmtop-row">
	  <th class="rsm_td1">RSM Name</th>
	  <th class="rsm_td2">Previous Year</th>
	  <th class="rsm_td3">Current Year</th>
	
      </tr>
      </thead>
      <tbody>
	<tr>
	  <td><label>Years For <span class="rsm_req">*</span></label></td>
	  <td><input type="text" name="rsm_y1" id="rsm_y1" value="<?php echo isset($rsm_y1)? $rsm_y1 : get_option('rsm_y1',false); ?>" /></td>
	  <td><input type="text" name="rsm_y2" id="rsm_y2" value="<?php echo isset($rsm_y2)? $rsm_y2 : get_option('rsm_y2',false); ?>" /></td>
	</tr>
	<tr>
	    <td><label>Max Allowable Pension Cap <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_allowable_pension_threshold_y1" id="rsm_max_allowable_pension_threshold_y1" value="<?php echo isset($rsm_max_allowable_pension_threshold_y1)? $rsm_max_allowable_pension_threshold_y1 : get_option('rsm_max_allowable_pension_threshold_y1',false); ?>" /></td>
	    <td><input type="text" name="rsm_max_allowable_pension_threshold_y2" id="rsm_max_allowable_pension_threshold_y2" value="<?php echo isset($rsm_max_allowable_pension_threshold_y2)? $rsm_max_allowable_pension_threshold_y2 : get_option('rsm_max_allowable_pension_threshold_y2',false); ?>" /></td>
	</tr>
	<tr>
	    <td><label>Max Allowable Pension Cap (married with 2 incomes) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_allowable_pension_threshold_M2_y1" id="rsm_max_allowable_pension_threshold_M2_y1" value="<?php echo isset($rsm_max_allowable_pension_threshold_M2_y1)? $rsm_max_allowable_pension_threshold_M2_y1 : get_option('rsm_max_allowable_pension_threshold_M2_y1',false); ?>" /></td>
	    <td><input type="text" name="rsm_max_allowable_pension_threshold_M2_y2" id="rsm_max_allowable_pension_threshold_M2_y2" value="<?php echo isset($rsm_max_allowable_pension_threshold_M2_y2)? $rsm_max_allowable_pension_threshold_M2_y2 : get_option('rsm_max_allowable_pension_threshold_M2_y2',false); ?>" /></td>
	</tr>
	<!-- Max Pension Contribution based on Age -->
	<tr>
	    <td colspan="3"><strong>Max Pension Contribution based on Age  :</strong></td>
	</tr>
	<tr> 
	    <td><label>Less than 30 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[0])? $rsm_max_pension_age_y1[0] : $saved_rsm_max_pension_age_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[0])? $rsm_max_pension_age_y2[0] : $saved_rsm_max_pension_age_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>30 but less than 40 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[1])? $rsm_max_pension_age_y1[1] : $saved_rsm_max_pension_age_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[1])? $rsm_max_pension_age_y2[1] : $saved_rsm_max_pension_age_y2[1]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>40 but less than 50 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[2])? $rsm_max_pension_age_y1[2] : $saved_rsm_max_pension_age_y1[2]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[2])? $rsm_max_pension_age_y2[2] : $saved_rsm_max_pension_age_y2[2]; ?>" /></td>
	</tr>
        <tr> 
	    <td><label>50 but less than 55 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[3])? $rsm_max_pension_age_y1[3] : $saved_rsm_max_pension_age_y1[3]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[3])? $rsm_max_pension_age_y2[3] : $saved_rsm_max_pension_age_y2[3]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>50 but less than 55 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[4])? $rsm_max_pension_age_y1[4] : $saved_rsm_max_pension_age_y1[4]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[4])? $rsm_max_pension_age_y2[4] : $saved_rsm_max_pension_age_y2[4]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>55 but less than 60 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[5])? $rsm_max_pension_age_y1[5] : $saved_rsm_max_pension_age_y1[5]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[5])? $rsm_max_pension_age_y2[5] : $saved_rsm_max_pension_age_y2[5]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>60 and over <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_max_pension_age_y1[]" id="rsm_max_pension_age_y1" value="<?php echo isset($rsm_max_pension_age_y1[6])? $rsm_max_pension_age_y1[6] : $saved_rsm_max_pension_age_y1[6]; ?>" /></td>
	    <td><input type="text" name="rsm_max_pension_age_y2[]" id="rsm_max_pension_age_y2" value="<?php echo isset($rsm_max_pension_age_y2[6])? $rsm_max_pension_age_y2[6] : $saved_rsm_max_pension_age_y2[6]; ?>" /></td>
	</tr>
	<!-- Tax payable -->
	<tr>
	    <td colspan="3"><strong>Tax payable :</strong> </td>
	</tr>
	<tr> 
	    <td><label>Tax payable (1st Percentage) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_payable_y1[]" id="rsm_payable_y1" value="<?php echo isset($rsm_payable_y1[0])? $rsm_payable_y1[0] : $saved_rsm_payable_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_payable_y2[]" id="rsm_payable_y2" value="<?php echo isset($rsm_payable_y2[0])? $rsm_payable_y2[0] : $saved_rsm_payable_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Tax payable (2nd Percentage) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_payable_y1[]" id="rsm_payable_y1" value="<?php echo isset($rsm_payable_y1[1])? $rsm_payable_y1[1] : $saved_rsm_payable_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_payable_y2[]" id="rsm_payable_y2" value="<?php echo isset($rsm_payable_y2[1])? $rsm_payable_y2[1] : $saved_rsm_payable_y2[1]; ?>" /></td>
	</tr>
	<!-- Tax Cutoff Figure -->
	<tr>
	    <td colspan="3"><strong>Tax Cutoff Figure :</strong> </td>
	</tr>
	<tr> 
	    <td><label>Tax Cutoff Figure (Single) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y1[]" id="rsm_tax_cutoff_fig_y1" value="<?php echo isset($rsm_tax_cutoff_fig_y1[0])? $rsm_tax_cutoff_fig_y1[0] : $saved_rsm_tax_cutoff_fig_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y2[]" id="rsm_tax_cutoff_fig_y2" value="<?php echo isset($rsm_tax_cutoff_fig_y2[0])? $rsm_tax_cutoff_fig_y2[0] : $saved_rsm_tax_cutoff_fig_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Tax Cutoff Figure (Married with one income) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y1[]" id="rsm_tax_cutoff_fig_y1" value="<?php echo isset($rsm_tax_cutoff_fig_y1[1])? $rsm_tax_cutoff_fig_y1[1] : $saved_rsm_tax_cutoff_fig_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y2[]" id="rsm_tax_cutoff_fig_y2" value="<?php echo isset($rsm_tax_cutoff_fig_y2[1])? $rsm_tax_cutoff_fig_y2[1] : $saved_rsm_tax_cutoff_fig_y2[1]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Tax Cutoff Figure (Married with two incomes) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y1[]" id="rsm_tax_cutoff_fig_y1" value="<?php echo isset($rsm_tax_cutoff_fig_y1[2])? $rsm_tax_cutoff_fig_y1[2] : $saved_rsm_tax_cutoff_fig_y1[2]; ?>" /></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y2[]" id="rsm_tax_cutoff_fig_y2" value="<?php echo isset($rsm_tax_cutoff_fig_y2[2])? $rsm_tax_cutoff_fig_y2[2] : $saved_rsm_tax_cutoff_fig_y2[2]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Tax Cutoff Figure (Widowed) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y1[]" id="rsm_tax_cutoff_fig_y1" value="<?php echo isset($rsm_tax_cutoff_fig_y1[3])? $rsm_tax_cutoff_fig_y1[3] : $saved_rsm_tax_cutoff_fig_y1[3]; ?>" /></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y2[]" id="rsm_tax_cutoff_fig_y2" value="<?php echo isset($rsm_tax_cutoff_fig_y2[3])? $rsm_tax_cutoff_fig_y2[3] : $saved_rsm_tax_cutoff_fig_y2[3]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Tax Cutoff Figure (Widowed with children) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y1[]" id="rsm_tax_cutoff_fig_y1" value="<?php echo isset($rsm_tax_cutoff_fig_y1[4])? $rsm_tax_cutoff_fig_y1[4] : $saved_rsm_tax_cutoff_fig_y1[4]; ?>" /></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y2[]" id="rsm_tax_cutoff_fig_y2" value="<?php echo isset($rsm_tax_cutoff_fig_y2[4])? $rsm_tax_cutoff_fig_y2[4] : $saved_rsm_tax_cutoff_fig_y2[4]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Tax Cutoff Figure (Lone parent) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y1[]" id="rsm_tax_cutoff_fig_y1" value="<?php echo isset($rsm_tax_cutoff_fig_y1[5])? $rsm_tax_cutoff_fig_y1[5] : $saved_rsm_tax_cutoff_fig_y1[5]; ?>" /></td>
	    <td><input type="text" name="rsm_tax_cutoff_fig_y2[]" id="rsm_tax_cutoff_fig_y2" value="<?php echo isset($rsm_tax_cutoff_fig_y2[5])? $rsm_tax_cutoff_fig_y2[5] : $saved_rsm_tax_cutoff_fig_y2[5]; ?>" /></td>
	</tr>
	<!-- Income Exempt  -->
	<tr>
	    <td colspan="3"><strong>Income Exempt  :</strong> </td>
	</tr>
	<tr> 
	    <td><label>Income Exempt from PRSI <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_inc_exemp_y1[]" id="rsm_inc_exemp_y1" value="<?php echo isset($rsm_inc_exemp_y1[0])? $rsm_inc_exemp_y1[0] : $saved_rsm_inc_exemp_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_inc_exemp_y2[]" id="rsm_inc_exemp_y2" value="<?php echo isset($rsm_inc_exemp_y2[0])? $rsm_inc_exemp_y2[0] : $saved_rsm_inc_exemp_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Income Exempt from PRSI (married with 2 incomes) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_inc_exemp_y1[]" id="rsm_inc_exemp_y1" value="<?php echo isset($rsm_inc_exemp_y1[1])? $rsm_inc_exemp_y1[1] : $saved_rsm_inc_exemp_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_inc_exemp_y2[]" id="rsm_inc_exemp_y2" value="<?php echo isset($rsm_inc_exemp_y2[1])? $rsm_inc_exemp_y2[1] : $saved_rsm_inc_exemp_y2[1]; ?>" /></td>
	</tr>
	<!-- PRSI  -->
	<tr>
	    <td colspan="3"><strong>PRSI  :</strong> </td>
	</tr>
	<tr> 
	    <td><label>PRSI Rate <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_prsi_opt_y1[]" id="rsm_prsi_opt_y1" value="<?php echo isset($rsm_prsi_opt_y1[0])? $rsm_prsi_opt_y1[0] : $saved_rsm_prsi_opt_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_prsi_opt_y2[]" id="rsm_prsi_opt_y2" value="<?php echo isset($rsm_prsi_opt_y2[0])? $rsm_prsi_opt_y2[0] : $saved_rsm_prsi_opt_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>PRSI Lower Threshold <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_prsi_opt_y1[]" id="rsm_prsi_opt_y1" value="<?php echo isset($rsm_prsi_opt_y1[1])? $rsm_prsi_opt_y1[1] : $saved_rsm_prsi_opt_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_prsi_opt_y2[]" id="rsm_prsi_opt_y2" value="<?php echo isset($rsm_prsi_opt_y2[1])? $rsm_prsi_opt_y2[1] : $saved_rsm_prsi_opt_y2[1]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>PRSI Lower Threshold (married with 2 incomes) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_prsi_opt_y1[]" id="rsm_prsi_opt_y1" value="<?php echo isset($rsm_prsi_opt_y1[2])? $rsm_prsi_opt_y1[2] : $saved_rsm_prsi_opt_y1[2]; ?>" /></td>
	    <td><input type="text" name="rsm_prsi_opt_y2[]" id="rsm_prsi_opt_y2" value="<?php echo isset($rsm_prsi_opt_y2[2])? $rsm_prsi_opt_y2[2] : $saved_rsm_prsi_opt_y2[2]; ?>" /></td>
	</tr>
	<!-- Income exempt from USC  -->
	<tr>
	    <td colspan="3"><strong>Income exempt from USC  :</strong> </td>
	</tr>
	<tr> 
	    <td><label>Income exempt from Universal Social Charge <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_inc_expUSC_y1[]" id="rsm_inc_expUSC_y1" value="<?php echo isset($rsm_inc_expUSC_y1[0])? $rsm_inc_expUSC_y1[0] : $saved_rsm_inc_expUSC_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_inc_expUSC_y2[]" id="rsm_inc_expUSC_y2" value="<?php echo isset($rsm_inc_expUSC_y2[0])? $rsm_inc_expUSC_y2[0] : $saved_rsm_inc_expUSC_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Income exempt from Universal Social Charge (married with 2 incomes) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_inc_expUSC_y1[]" id="rsm_inc_expUSC_y1" value="<?php echo isset($rsm_inc_expUSC_y1[1])? $rsm_inc_expUSC_y1[1] : $saved_rsm_inc_expUSC_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_inc_expUSC_y2[]" id="rsm_inc_expUSC_y2" value="<?php echo isset($rsm_inc_expUSC_y2[1])? $rsm_inc_expUSC_y2[1] : $saved_rsm_inc_expUSC_y2[1]; ?>" /></td>
	</tr>
	<!-- USC Threshold   -->
	<tr>
	    <td colspan="3"><strong>USC Thresholds   :</strong> </td>
	</tr>
	<tr> 
	    <td><label>USC Threshold 1 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_usc_thres_y1[]" id="rsm_usc_thres_y1" value="<?php echo isset($rsm_usc_thres_y1[0])? $rsm_usc_thres_y1[0] : $saved_rsm_usc_thres_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_usc_thres_y2[]" id="rsm_usc_thres_y2" value="<?php echo isset($rsm_usc_thres_y2[0])? $rsm_usc_thres_y2[0] : $saved_rsm_usc_thres_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>USC Threshold 1 (married with 2 incomes) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_usc_thres_y1[]" id="rsm_usc_thres_y1" value="<?php echo isset($rsm_usc_thres_y1[1])? $rsm_usc_thres_y1[1] : $saved_rsm_usc_thres_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_usc_thres_y2[]" id="rsm_usc_thres_y2" value="<?php echo isset($rsm_usc_thres_y2[1])? $rsm_usc_thres_y2[1] : $saved_rsm_usc_thres_y2[1]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>USC Threshold 2 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_usc_thres_y1[]" id="rsm_usc_thres_y1" value="<?php echo isset($rsm_usc_thres_y1[2])? $rsm_usc_thres_y1[2] : $saved_rsm_usc_thres_y1[2]; ?>" /></td>
	    <td><input type="text" name="rsm_usc_thres_y2[]" id="rsm_usc_thres_y2" value="<?php echo isset($rsm_usc_thres_y2[2])? $rsm_usc_thres_y2[2] : $saved_rsm_usc_thres_y2[2]; ?>" /></td>
	</tr>
	<!-- USC Percentage  -->
	<tr>
	    <td colspan="3"><strong>USC Percentage :</strong> </td>
	</tr>
	<tr> 
	    <td><label>USC Percentage 1 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_usc_percent_y1[]" id="rsm_usc_percent_y1" value="<?php echo isset($rsm_usc_percent_y1[0])? $rsm_usc_percent_y1[0] : $saved_rsm_usc_percent_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_usc_percent_y2[]" id="rsm_usc_percent_y2" value="<?php echo isset($rsm_usc_percent_y2[0])? $rsm_usc_percent_y2[0] : $saved_rsm_usc_percent_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>USC Percentage 2 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_usc_percent_y1[]" id="rsm_usc_percent_y1" value="<?php echo isset($rsm_usc_percent_y1[1])? $rsm_usc_percent_y1[1] : $saved_rsm_usc_percent_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_usc_percent_y2[]" id="rsm_usc_percent_y2" value="<?php echo isset($rsm_usc_percent_y2[1])? $rsm_usc_percent_y2[1] : $saved_rsm_usc_percent_y2[1]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>USC Percentage 3 <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_usc_percent_y1[]" id="rsm_usc_percent_y1" value="<?php echo isset($rsm_usc_percent_y1[2])? $rsm_usc_percent_y1[2] : $saved_rsm_usc_percent_y1[2]; ?>" /></td>
	    <td><input type="text" name="rsm_usc_percent_y2[]" id="rsm_usc_percent_y2" value="<?php echo isset($rsm_usc_percent_y2[2])? $rsm_usc_percent_y2[2] : $saved_rsm_usc_percent_y2[2]; ?>" /></td>
	</tr>
	<!-- Tax credits  -->
	<tr>
	    <td colspan="3"><strong>Tax credits :</strong> </td>
	</tr>
	<tr> 
	    <td><label>Personal tax credit (single) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[0])? $rsm_tex_credits_y1[0] : $saved_rsm_tex_credits_y1[0]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[0])? $rsm_tex_credits_y2[0] : $saved_rsm_tex_credits_y2[0]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Personal tax credit (married) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[1])? $rsm_tex_credits_y1[1] : $saved_rsm_tex_credits_y1[1]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[1])? $rsm_tex_credits_y2[1] : $saved_rsm_tex_credits_y2[1]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Personal tax credit (widowed) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[3])? $rsm_tex_credits_y1[3] : $saved_rsm_tex_credits_y1[3]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[3])? $rsm_tex_credits_y2[3] : $saved_rsm_tex_credits_y2[3]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Personal tax credit (widowed with children) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[4])? $rsm_tex_credits_y1[4] : $saved_rsm_tex_credits_y1[4]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[4])? $rsm_tex_credits_y2[4] : $saved_rsm_tex_credits_y2[4]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Single Parent tax credit <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[5])? $rsm_tex_credits_y1[5] : $saved_rsm_tex_credits_y1[5]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[5])? $rsm_tex_credits_y2[5] : $saved_rsm_tex_credits_y2[5]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Employee (PAYE) tax credit <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[6])? $rsm_tex_credits_y1[6] : $saved_rsm_tex_credits_y1[6]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[6])? $rsm_tex_credits_y2[6] : $saved_rsm_tex_credits_y2[6]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Home carer tax credit (married 1 income) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[7])? $rsm_tex_credits_y1[7] : $saved_rsm_tex_credits_y1[7]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[7])? $rsm_tex_credits_y2[7] : $saved_rsm_tex_credits_y2[7]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Age tax credit (over 65) <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[8])? $rsm_tex_credits_y1[8] : $saved_rsm_tex_credits_y1[8]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[8])? $rsm_tex_credits_y2[8] : $saved_rsm_tex_credits_y2[8]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Blind person tax credit <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[2])? $rsm_tex_credits_y1[2] : $saved_rsm_tex_credits_y1[2]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[2])? $rsm_tex_credits_y2[2] : $saved_rsm_tex_credits_y2[2]; ?>" /></td>
	</tr>
	<tr> 
	    <td><label>Incapacitated child tax credit <span class="rsm_req">*</span></label></td>
	    <td><input type="text" name="rsm_tex_credits_y1[]" id="rsm_tex_credits_y1" value="<?php echo isset($rsm_tex_credits_y1[9])? $rsm_tex_credits_y1[9] : $saved_rsm_tex_credits_y1[9]; ?>" /></td>
	    <td><input type="text" name="rsm_tex_credits_y2[]" id="rsm_tex_credits_y2" value="<?php echo isset($rsm_tex_credits_y2[9])? $rsm_tex_credits_y2[9] : $saved_rsm_tex_credits_y2[9]; ?>" /></td>
	</tr>
      </tbody>
      <tfoot>
	 <tr>
	  <td  colspan="3"><input type="submit" name="rsmSubBtn" id="rsmSubBtn" value="Submit" class="button button-primary button-large" /></td>
	 </tr>
      </tfoot>
    </table>
    
  </form>
</div><!-- end of main warp div  -->