<?php
/*
Plugin Name: RSM Budget Calculator 
Plugin URI: http://www.rsmfarrellgrantsparks.ie
Description: used to calculate the budget   

Author: rsmfarrellgrantsparks.ie
Version: 1.0

*/
global $wpdb;
/* define the Root for URL and Document */
define('RSM_DOCROOT',    dirname(__FILE__));
define('RSM_PLUGURL',    plugin_dir_url(__FILE__));
define('RSM_WEBROOT',    str_replace(getcwd(), home_url(), dirname(__FILE__)));

/* load all files  */
function rsm_ModelsAutoLoader($class) {
  if (!class_exists($class) && is_file(RSM_DOCROOT.'/libs/'.$class.'.class.php')) {    
     include RSM_DOCROOT.'/libs/' . $class . '.class.php';
  } 
}
spl_autoload_register('rsm_ModelsAutoLoader');


/* call the install and uninstall actions */
$rsmBasic =rsmBasicActions :: RSMgetInstance();

$rsmInstaller= rsmInstaller :: RSMgetInstance(); 
if(class_exists('rsmInstaller'))
{
    register_activation_hook(__FILE__, array($rsmInstaller,'rsmInstaller') );
}

register_uninstall_hook(__FILE__, 'rsmUnistaller');
function rsmUnistaller()
{
  global $wpdb;    
  delete_option('rsm_activate');
  delete_option('rsm_permalink_structure');
 
}

?>